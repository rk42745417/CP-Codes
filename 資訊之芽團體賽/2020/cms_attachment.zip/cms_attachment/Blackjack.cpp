#include "Blackjack.h"

//----do not modify above----

void play() {
    // finish this function
    
}

//----do not modify below----

#ifndef EVAL
namespace {
    int dealer_busted = 0;
    void _wa(string s) {
        cout << "Wrong_answer: " << s << endl;
        exit(0);
    }
    void _ac(string s) {
        cout << "Accepted: " << s << endl;
        exit(0);
    }
    const int POKER_NUM = 5000;
    const int INIT_MONEY = 1000000;
    const int TARGET = 1.3 * INIT_MONEY;
    int money_you_have;
    int card_ptr;
    bool poker_exceed;
    vector<int> cards;
    vector<int> your_card, dealer_card;
    vector<int> card1, card2;
    int can_mask = 0;
    const int INIT_GAME = 0;
    const int BUY_INSURANCE = 1;
    const int DOUBLE_DOWN = 2;
    const int SPLIT = 3;
    const int HIT1 = 4;
    const int STAND1 = 5;
    const int HIT2 = 6;
    const int STAND2 = 7;
    const int HIT = 8;
    const int STAND = 9;
    const string oper[10] = {"init_game", "buy_insurance", "double_down", "split", "hit1", "stand1", "hit2", "stand2", "hit", "stand"};
    int now_bet = 0;

    int f(int x) {
        if (x <= 10) return x;
        else return 10;
    }
    
    void play_game(int seed) {
        money_you_have = INIT_MONEY;
        card_ptr = 0;
        poker_exceed = false;
        for (int i = 0; i < POKER_NUM; ++i) {
            for (int j = 0; j < 4; ++j) {
                for (int k = 1; k <= 13; ++k) {
                    cards.push_back(k);
                }
            }
        }
        mt19937 rng(seed);
        shuffle(cards.begin(), cards.end(), rng);
        shuffle(cards.begin(), cards.end(), rng);
        shuffle(cards.begin(), cards.end(), rng);
        shuffle(cards.begin(), cards.end(), rng);
        shuffle(cards.begin(), cards.end(), rng);
        shuffle(cards.begin(), cards.end(), rng);
        can_mask = (1 << INIT_GAME);
        while (0 < bet_you_have() &&  bet_you_have() < TARGET && !poker_exceed) {
            play();
        }
        if (bet_you_have() >= TARGET && !poker_exceed) {
            _ac("You have " + to_string(money_you_have) + " , and you spend " + to_string(card_ptr) + " cards (" + to_string(card_ptr / 52) + " pokers)");
        }
        else {
            _wa("Fail to win " + to_string(TARGET) + ", your bet is " + to_string(bet_you_have()));
        }
    }

    int get_card() {
        int ret = cards[card_ptr];
        card_ptr++;
        if (card_ptr == POKER_NUM * 52) {
            poker_exceed = true;
            card_ptr = 0;
        }
        return ret;
    }

    void go_dealer() {
        while (cal_max_point(dealer_card) != -1 && cal_max_point(dealer_card) < 17) {
            dealer_card.push_back(get_card());
        }
    }

    void lose_win(vector<int> a, vector<int> b) {
        if (cal_max_point(b) == -1) {
            dealer_busted++;
        }
        if (win(a, b) == 0) {
            money_you_have += now_bet;
        }
        else if (win(a, b) == 1) {
            if (is_blackjack(a)) {
                money_you_have += now_bet * 5 / 2;
            }
            else {
                money_you_have += now_bet * 2;
            }
        }
    }

    void check_operation(int operation_now) {
        if ((can_mask & (1 << operation_now)) == 0) {
            string msg = "You are doing operation " + oper[operation_now] + ", while only ";
            vector<string> oks;
            for (int i = 0; i < 10; ++i) {
                if (((1 << i) & can_mask) != 0) {
                    oks.push_back(oper[i]);
                }
            }
            bool flag = false;
            for (string s: oks) {
                if (flag) msg += ", ";
                msg += s;
                flag = true;
            }
            msg += " is/are okay";
            _wa(msg);
        }
        return;
    }

    vector<int> _init_game(int bet) {
        check_operation(INIT_GAME);
        if (bet > money_you_have) {
            _wa("Bet too much, you have " + to_string(money_you_have) + ", but you bet " + to_string(bet));
        }
        if (bet <= 0) {
            _wa("Bet too small, you bet " + to_string(bet));
        }
        now_bet = bet;
        money_you_have -= now_bet;
        your_card.clear(); dealer_card.clear();
        your_card.push_back(get_card()); dealer_card.push_back(get_card());
        your_card.push_back(get_card()); dealer_card.push_back(get_card());
        vector<int> ret = your_card;
        ret.push_back(dealer_card[0]);
        can_mask = 0;
        if (dealer_card[0] == 1) {
            can_mask |= (1 << BUY_INSURANCE);
        }
        else {
            can_mask |= (1 << DOUBLE_DOWN);
            can_mask |= (1 << HIT);
            can_mask |= (1 << STAND);
            if (f(your_card[0]) == f(your_card[1])) {
                can_mask |= (1 << SPLIT);
            }
        }
        return ret;
    }

    int _buy_insurance(int insurance_bet) {
        check_operation(BUY_INSURANCE);
        if (insurance_bet * 2 > now_bet) {
            _wa("Insurance bet too much, your last bet is " + to_string(now_bet) + ", but your insurance bet is " + to_string(insurance_bet));
        }
        if (insurance_bet > money_you_have) {
            _wa("Insurance bet too much, you have " + to_string(money_you_have) + ", but your insurance bet is " + to_string(insurance_bet));
        }
        money_you_have -= insurance_bet;
        if (is_blackjack(dealer_card)) {
            money_you_have += 2 * insurance_bet;
            can_mask = 0;
            can_mask |= (1 << STAND);
            return 1;
        }
        else {
            can_mask = 0;
            can_mask |= (1 << DOUBLE_DOWN);
            can_mask |= (1 << HIT);
            can_mask |= (1 << STAND);
            if (f(your_card[0]) == f(your_card[1])) {
                can_mask |= (1 << SPLIT);
            }
            return 0;
        }
    }

    int _double_down() {
        check_operation(DOUBLE_DOWN);
        if (now_bet > money_you_have) {
            _wa("Double down too much, you have " + to_string(money_you_have) + ", but your last bet is " + to_string(now_bet));
        }
        money_you_have -= now_bet;
        now_bet <<= 1;
        your_card.push_back(get_card());
        can_mask = 0;
        can_mask |= (1 << STAND);
        return your_card.back();
    }

    vector<int> _split() {
        check_operation(SPLIT);
        if (now_bet > money_you_have) {
            _wa("Split too much, you have " + to_string(money_you_have) + ", but your last bet is " + to_string(now_bet));
        }
        money_you_have -= now_bet;
        can_mask = 0;
        card1.clear(), card2.clear();
        card1.push_back(your_card[0]), card2.push_back(your_card[1]);
        vector<int> ret;
        ret.push_back(get_card()); ret.push_back(get_card());
        card1.push_back(ret[0]), card2.push_back(ret[1]);
        can_mask = 0;
        can_mask |= (1 << STAND1);
        can_mask |= (1 << HIT1);
        return ret;
    }

    int _hit_1() {
        check_operation(HIT1);
        card1.push_back(get_card());
        can_mask = 0;
        if (cal_max_point(card1) == -1) {
            can_mask |= (1 << STAND1);
        }
        else {
            can_mask |= (1 << HIT1);
            can_mask |= (1 << STAND1);
        }
        return card1.back();
    }

    void _stand_1() {
        check_operation(STAND1);
        can_mask = 0;
        can_mask |= (1 << STAND2);
        can_mask |= (1 << HIT2);
    }

    int _hit_2() {
        check_operation(HIT2);
        card2.push_back(get_card());
        can_mask = 0;
        if (cal_max_point(card2) == -1) {
            can_mask |= (1 << STAND2);
        }
        else {
            can_mask |= (1 << HIT2);
            can_mask |= (1 << STAND2);
        }
        return card2.back();
    }

    vector<int> _stand_2() {
        check_operation(STAND2);
        go_dealer();
        lose_win(card1, dealer_card);
        lose_win(card2, dealer_card);
        can_mask = 0;
        can_mask = (1 << INIT_GAME);
        return dealer_card;
    }

    int _hit() {
        check_operation(HIT);
        your_card.push_back(get_card());
        can_mask = 0;
        if (cal_max_point(your_card) == -1) {
            can_mask |= (1 << STAND);
        }
        else {
            can_mask |= (1 << HIT);
            can_mask |= (1 << STAND);
        }
        return your_card.back();
    }

    vector<int> _stand() {
        check_operation(STAND);
        go_dealer();
        lose_win(your_card, dealer_card);
        can_mask = 0;
        can_mask = (1 << INIT_GAME);
        return dealer_card;
    }
}

vector<int> init_game(int bet) {
    return _init_game(bet);
}

int buy_insurance(int insurance_bet) {
    return _buy_insurance(insurance_bet);
}

int double_down() {
    return _double_down();
}

vector<int> split() {
    return _split();
}

int hit_1() {
    return _hit_1();
}

void stand_1() {
    _stand_1();
}

int hit_2() {
    return _hit_2();
}

vector<int> stand_2() {
    return _stand_2();
}

int hit() {
    return _hit();
}

vector<int> stand() {
    return _stand();
}

bool is_blackjack(vector<int> v) { // check card is blackjack or not
    if (v.size() != 2) return false;
    for (int &i: v) {
        i = f(i);
    }
    if (v[0] == 1 && v[1] == 10) return true;
    if (v[0] == 10 && v[1] == 1) return true;
    return false;
}

vector<int> cal_point(vector<int> v) { // calculate the point of a hand
    int sum = 0;
    bool have_1 = false;
    for (int &i: v) {
        i = f(i);
        sum += i;
        if (i == 1) {
            have_1 = true;
        }
    }
    vector<int> ret;
    if (sum > 21) {
        ret.push_back(-1);
    }
    else {
        ret.push_back(sum);
        if (have_1 && sum <= 11) {
            ret.push_back(sum + 10);
        }
    }
    return ret;
}

int cal_max_point(vector<int> v) { // calculate the maximum point
    vector<int> ret = cal_point(v);
    return ret.back();
}

int win(vector<int> a, vector<int> b) { // your card is a, dealer is b
    if (is_blackjack(a) && is_blackjack(b)) return 0;
    else if (is_blackjack(a)) return 1;
    else if (is_blackjack(b)) return -1;
    int pta = cal_max_point(a), ptb = cal_max_point(b);
    if (pta == -1) return -1;
    if (pta > ptb) return 1;
    else if (pta < ptb) return -1;
    else return 0;
}

int bet_you_have() { // return the money you have so far
    return money_you_have;
}

int main () {
    unsigned int x; cin >> x;
    play_game(x);
}
#endif
