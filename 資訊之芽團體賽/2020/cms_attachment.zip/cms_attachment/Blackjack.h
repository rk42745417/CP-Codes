#ifndef _BLACKJACK_H_
#define _BLACKJACK_H_
#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
using namespace std;

void play(); // playing function: student write

vector<int> init_game(int bet);

int buy_insurance(int insurance_bet);

int double_down(); // return the card you get

vector<int> split();

int hit_1();

void stand_1();

int hit_2();

vector<int> stand_2();

int hit();

vector<int> stand();

bool is_blackjack(vector<int> v); // check card is blackjack or not

vector<int> cal_point(vector<int> v); // calculate the point of a hand

int cal_max_point(vector<int> v); // calculate the maximum point

int win(vector<int> a, vector<int> b); // your card is a, dealer is b

int bet_you_have(); // return the money you have so far

#endif
