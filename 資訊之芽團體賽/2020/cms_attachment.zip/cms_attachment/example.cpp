#include "Blackjack.h"

void play() {
    int now_bet = bet_you_have();
    vector<int> v = init_game(now_bet / 10);
    vector<int> aa;
    aa.push_back(v[0]); aa.push_back(v[1]);
    if (v[2] == 1) {
        int x = buy_insurance(now_bet / 30);
        if (x == 1) {
            vector<int> xx = stand();
            // do something
            return;
        }
    }
    if (is_blackjack(aa)) {
        // you are blackjack
        vector<int> xx = stand();
        // do something
        return;
    }
    if (v[0] == v[1]) {
        // split
        vector<int> vv = split();
        vector<int> c1, c2;
        c1.push_back(aa[0]); c1.push_back(vv[0]);
        c2.push_back(aa[1]); c2.push_back(vv[1]);
        while (cal_max_point(c1) != -1 && cal_max_point(c1) <= 14) {
            // hit until point > 14
            int x = hit_1();
            c1.push_back(x);
        }
        stand_1();
        vector<int> xx = stand_2();
        // do something
        return;
    }
    if (cal_max_point(aa) <= 10) {
        double_down();
        stand();
        // do something
        return;
    }
    hit();
    stand();
    // do something
}
