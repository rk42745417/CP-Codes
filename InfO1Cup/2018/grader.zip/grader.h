#include<bits/stdc++.h>

using namespace std;

bool isSubsequence (vector < int > v);
vector < int > findSequence (int N);

